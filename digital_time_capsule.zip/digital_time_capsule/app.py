from flask import Flask, render_template, request, redirect, session
import mysql.connector
from flask_bcrypt import Bcrypt
import os
from datetime import date

app = Flask(__name__)
app.secret_key = "secret123"

bcrypt = Bcrypt(app)

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

db = mysql.connector.connect(
host="localhost",
user="root",
password="yourpassword",
database="time_capsule"
)

cursor = db.cursor()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        hashed = bcrypt.generate_password_hash(password).decode("utf-8")

        cursor.execute(
        "INSERT INTO users(username,email,password) VALUES(%s,%s,%s)",
        (username,email,hashed))

        db.commit()
        return redirect("/login")

    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        cursor.execute("SELECT * FROM users WHERE email=%s",(email,))
        user = cursor.fetchone()

        if user and bcrypt.check_password_hash(user[3],password):
            session["user_id"] = user[0]
            session["username"] = user[1]

            return redirect("/dashboard")

    return render_template("login.html")

@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        return redirect("/login")

    return render_template("dashboard.html")

@app.route("/upload", methods=["GET","POST"])
def upload():

    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":

        title = request.form["title"]
        unlock_date = request.form["unlock_date"]
        file = request.files["file"]

        filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(filepath)

        cursor.execute(
        "INSERT INTO memories(user_id,title,file_path,unlock_date) VALUES(%s,%s,%s,%s)",
        (session["user_id"],title,filepath,unlock_date)
        )

        db.commit()

        return redirect("/memories")

    return render_template("upload.html")

@app.route("/memories")
def memories():

    if "user_id" not in session:
        return redirect("/login")

    today = date.today()

    cursor.execute(
    "SELECT * FROM memories WHERE user_id=%s AND unlock_date<=%s",
    (session["user_id"],today)
    )

    memories = cursor.fetchall()

    return render_template("memories.html",memories=memories)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)