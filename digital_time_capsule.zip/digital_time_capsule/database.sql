CREATE DATABASE time_capsule;

USE time_capsule;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
email VARCHAR(100),
password VARCHAR(255)
);

CREATE TABLE memories(
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
title VARCHAR(255),
file_path VARCHAR(255),
unlock_date DATE,
upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY(user_id) REFERENCES users(id)
);